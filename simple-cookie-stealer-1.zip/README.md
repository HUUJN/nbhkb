# 🍪 Simple Cookie Stealer

**Simple Cookie Stealer** is probably both the most basic and best Cookie Stealer out there. <br>
It is not bloated with flashy embeds, images, or features. Instead, it strives to be extremely fast and small, and steal from all browsers.

If you're struggling, the [Video Tutorial](https://youtu.be/iSMlgeEVqvE) may help.

# 💎 Features

* Clean Embed System
* Crawls For Browsers (So it steals from truly **every** browser)
* Simple and Fast, takes no more than 2 seconds to finish.

# 🛠️ Usage

Usage is extremely simple! <br>

* **1)** Firstly, make sure Python is installed. [Click Here](https://www.python.org/downloads/) to install! **NOTE:** Make sure to check "Add Python to PATH" when installing! <br>
* **2)** Install the requirements by running `pip install -r requirements.txt` in your terminal.
* **3)** Run `build.py`, configure how you please with the GUI, and send your payload to victims! 😈 <br>

# 🌠 Closing Statements

Thank you for using my tools! If this helps, **star!**

You can also try my other tools! Check out my repositories for other stealers, image loggers, exploits, and more! <br>
Enjoy your day :)
